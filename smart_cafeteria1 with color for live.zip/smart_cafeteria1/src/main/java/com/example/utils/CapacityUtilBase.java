package com.example.utils;
import java.awt.Color;
public class CapacityUtilBase {
	
	static Color red = Color.RED;
	static Color green = Color.GREEN;
	static Color yellow= Color.YELLOW;
	public static String FindTypeService(Integer k) {
		
		if(k>0 && k<20) {
			return "FREE";
		}
		else if(k>21 && k<40)
		{
			return "MODERATE";
		}
		else
		{
			return "CROWDED";
		}
	}

	public static String FindTypeDining(Integer k)
	{
		if(k>0 && k<50) {
			return "FREE";
		}
		else if(k>51 && k<100)
		{
			return "MODERATE";
		}
		else
		{
			return "CROWDED";
		}
	}

	public static String FindColorDining(Integer k) {
		
		if(k>0 && k<50) {
			return "'green'";
		}
		else if(k>51 && k<100)
		{
			return "'yellow'";
		}
		else
		{
			return "'red'";
		}
	}

	public static String FindColorSevice(Integer k) {
		if(k>0 && k<20) {
			return "'green'";
		}
		else if(k>21 && k<40)
		{
			return "'yellow'";
		}
		else
		{
			return "'red'";
		}
	}


}
