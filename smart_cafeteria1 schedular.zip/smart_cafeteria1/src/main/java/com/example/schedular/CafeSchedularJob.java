package com.example.schedular;

import java.util.Date;
import java.util.Random;

import org.apache.log4j.Logger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.example.controller.CafeteriaController;
import com.example.service.CafeteriaService;

public class CafeSchedularJob implements Job{
	public static int  selected=10;
	
	private static final Logger logger = Logger.getLogger(CafeSchedularJob.class);
	/*
	 @Autowired
	 private SessionFactory sessionFactory;
    
	@Autowired
	CafeteriaService cafeteriaService;
	@Autowired
	CafeteriaController cafe;

	public CafeteriaService getCafeteriaService() {
		return cafeteriaService;
	}

	public void setCafeteriaService(CafeteriaService cafeteriaService) {
		this.cafeteriaService = cafeteriaService;
	}*/

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		
		logger.info("Schedular Job is running...");
		
		

			Random rand = new Random();
			selected = rand.nextInt(100);
			 
			
			//ApplicationContext contextInstance = RestClientTracker.getInstance().getApplicationContext();
			
			System.out.println("execute");
			System.out.println("add service call in " + new Date().toString());
			//JobKey jobKey = context.getJobDetail().getKey();
		    //logger.info("SimpleJob says: " + jobKey + " executing at " + new Date());
			

	
		
	}
	/*@Scheduled(fixedDelay = 10000 ,initialDelay = 10000)
	public void postingdata() {
		System.out.println("hiiiii");
//		cafe.save();
	}*/
	
	
}
