package com.example.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;
import javax.transaction.Transactional;


import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaQuery;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.SessionFactoryImpl;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Repository;

import com.example.model.CafeOccupancyIntermediate;
import com.example.model.Cafeteria;
import com.example.schedular.CafeSchedularJob;


@Repository
@Transactional
public class CafeteriaRepository {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	@Transactional
	public Cafeteria save(Cafeteria cafeteria){
		 Session session = this.sessionFactory.getCurrentSession();
		 session.save(cafeteria);
		 return cafeteria;
	}
	
	
	public List<Cafeteria> getAllUsers() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Cafeteria>  cafeteriaList = session.createQuery("from Cafeteria",Cafeteria.class).getResultList();
		return cafeteriaList;
	}
	
	public Cafeteria getDetails(long id) {
		Session session = this.sessionFactory.getCurrentSession();
		Cafeteria cafeteria = (Cafeteria) session.get(Cafeteria.class, id);
		return cafeteria;
	}
	
	
	

	
	
	public JSONArray getDiffTimeCountByServiceArea() throws ParseException {
		Session session = this.sessionFactory.getCurrentSession();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<Cafeteria> results=null;
		Date dt=new Date();
		JSONArray responseArray = new JSONArray();
		try 
		{
		 Calendar c = Calendar.getInstance();
	     c.setTime(dt);
	     c.add(Calendar.MINUTE, -5);
	     Date dtime = c.getTime();
	     for(int i=1; i<2; i++)
	     {
			String spaceType = "";
			if(i==1){
				spaceType = "Service Area";
				}
			else{
				spaceType = "Dining Area";
				}
			System.out.println(spaceType);
		    CriteriaBuilder cb = session.getCriteriaBuilder();
			javax.persistence.criteria.CriteriaQuery<Cafeteria> query = cb.createQuery(Cafeteria.class);
			Root<Cafeteria> root = query.from(Cafeteria.class);
			Predicate[] predicates = new Predicate[3];
			predicates[0] = cb.lessThanOrEqualTo(root.get("inserted_datetime"),dt );
			predicates[1] = cb.greaterThanOrEqualTo(root.get("inserted_datetime"), dtime);
			predicates[2] = cb.equal(root.get("spacetype"), spaceType);
			query.select(root.get("peoplecount")).where(predicates);
			Query<Cafeteria> q = session.createQuery(query);
			results = q.getResultList();
			for (int j = 0; j < results.size(); j++) 
			{
				System.out.println(results);
				 JSONObject jsonObj = new JSONObject();
				 if(i==1){
				 jsonObj.put("Service Area", results.get(j));
				 }else{
				 jsonObj.put("Dining Area", results.get(j));
				 }
				 responseArray.put(jsonObj);
			}
		}
	    }
		catch(Exception e){
			e.printStackTrace();
			
		} 
		return responseArray;
		
	}
	
	public JSONArray TrendGraph() throws ParseException {
		Session session = this.sessionFactory.getCurrentSession();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<CafeOccupancyIntermediate> results=null;
		List<CafeOccupancyIntermediate> results1=null;
		//Date dt=new Date();
		
		String d= ("2020-12-17 13:05:00");  
	    Date dt=dateFormat.parse(d);
		JSONArray responseArray = new JSONArray();
		try 
		{
		 Calendar c = Calendar.getInstance();
	     c.setTime(dt);
	     c.add(Calendar.HOUR, -1);
	     Date dtime = c.getTime();
	     for(int i=0; i<2; i++)
	     {
			String spaceType = "";
			if(i==0){
				spaceType = "Service Area";
				}
			else{
				spaceType = "Dining Area";
				}
			System.out.println(spaceType);
		    CriteriaBuilder cb = session.getCriteriaBuilder();
			javax.persistence.criteria.CriteriaQuery<CafeOccupancyIntermediate> query = cb.createQuery(CafeOccupancyIntermediate.class);
			javax.persistence.criteria.CriteriaQuery<CafeOccupancyIntermediate> query1 = cb.createQuery(CafeOccupancyIntermediate.class);
			Root<CafeOccupancyIntermediate> root = query.from(CafeOccupancyIntermediate.class);
			Root<CafeOccupancyIntermediate> root1 = query1.from(CafeOccupancyIntermediate.class);
			Predicate[] predicates = new Predicate[3];
			predicates[0] = cb.lessThanOrEqualTo(root.get("created_date"),dt );
			predicates[1] = cb.greaterThanOrEqualTo(root.get("created_date"), dtime);
			predicates[2] = cb.equal(root.get("spacetype"), spaceType);
//			Path<Double> pc = root.get("peoplecount");
//			Path<String> ts = root.get( "timeslot");
//			query.multiselect(cb.array(pc,ts));
//			query.where(predicates);
			query.select(root.get("peoplecount")).where(predicates);
			query1.select(root1.get("timeslot")).where(predicates);
			//query.multiselect(root.get("peoplecount"),root.get("timeslot")).where(predicates);
			Query<CafeOccupancyIntermediate> q = session.createQuery(query);
			Query<CafeOccupancyIntermediate> q1 = session.createQuery(query1);
			results = q.getResultList();
			results1= q1.getResultList();
			for (int j = 0; j < results.size(); j++) 
			{
				 System.out.println(results);
				 JSONObject jsonObj = new JSONObject();
				 if(i==0){
					 jsonObj.put("timeslot", results1.get(j));
				 jsonObj.put("Service Area", results.get(j));
				
				 }else{
				 jsonObj.put("Dining Area", results.get(j));
				 jsonObj.put("timeslot", results1.get(j));
				 }
				 responseArray.put(jsonObj);
			}
		}
	    }
		catch(Exception e){
			e.printStackTrace();
			
		} 
		return responseArray;
		
	}
	
	
	
	@SuppressWarnings("unchecked")
	public JSONArray findAllByDatetimeBetween(Date startdate, Date enddate) {
		Session session = this.sessionFactory.getCurrentSession();
		JSONArray responseArray = new JSONArray();
		List<Cafeteria> results=null;
//		List<Cafeteria> results=session.createQuery("SELECT peoplecount FROM Cafeteria AS c WHERE (c.inserted_datetime BETWEEN :startdate AND :enddate) ")
//		.setParameter("startdate", startdate)
//		.setParameter("enddate", enddate)
//		.list();
		try {
		for(int i=0; i<2; i++)
	     {
			String spaceType = "";
			if(i==1){
				spaceType = "Service Area";
				}
			else{
				spaceType = "Dining Area";
				}
		CriteriaBuilder cb = session.getCriteriaBuilder();
		javax.persistence.criteria.CriteriaQuery<Cafeteria> query = cb.createQuery(Cafeteria.class);
		Root<Cafeteria> root = query.from(Cafeteria.class);
		Predicate[] predicates = new Predicate[3];
		predicates[0] = cb.greaterThanOrEqualTo(root.get("inserted_datetime"), startdate);
		predicates[1]  = cb.lessThanOrEqualTo(root.get("inserted_datetime"), enddate);
		predicates[2] = cb.equal(root.get("spacetype"), spaceType);
		query.select(root.get("peoplecount")).where(predicates);
		Query<Cafeteria> q = session.createQuery(query);
		results = q.getResultList();
		for (int j = 0; j < results.size(); j++) 
		{
			// System.out.println(results);
			 JSONObject jsonObj = new JSONObject();
			if(i==0) {
			 jsonObj.put("Dining Area", results.get(j));
			}else {
			 jsonObj.put("Service Area", results.get(j));
			}
			 responseArray.put(jsonObj);
		}}}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return responseArray;
		
	}
	
	

	@Transactional
	public void saveOccupancyBase(Cafeteria cafe) {
		Session session ;
		session= this.sessionFactory.getCurrentSession();
		System.out.println("in repo post");
		System.out.println(cafe);
		session.save(cafe);
	}

	

	public void saveOccupancyIntermediate(CafeOccupancyIntermediate ci) {
		Session session ;
		session= this.sessionFactory.getCurrentSession();
		System.out.println("in repo post");
		System.out.println(ci);
		session.save(ci);
	}

	
	public Double getFromBaseDining() throws ParseException {
		Session session = sessionFactory.getCurrentSession();
		List<Cafeteria> results=null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//Object avg = null;
		Double avg=null;
		System.out.println("done");
		System.out.println("repo insert");
		Date dt = new Date();
//		String d= ("2020-12-01 12:05:00");  
//	    Date date1=dateFormat.parse(d);
		try {
			 Calendar c = Calendar.getInstance();
		     c.setTime(dt);
		     c.add(Calendar.MINUTE, -30);
		     Date dtime = c.getTime();
		     System.out.println(dt);
		     System.out.println(dtime);
		CriteriaBuilder cb = session.getCriteriaBuilder();
		//javax.persistence.criteria.CriteriaQuery<Object> query = cb.createQuery(Object.class);
//		javax.persistence.criteria.CriteriaQuery<Cafeteria> query = cb.createQuery(Cafeteria.class);
//		Root<Cafeteria> root = query.from(Cafeteria.class);
//		Predicate[] predicates = new Predicate[3];
//		predicates[0] = cb.lessThanOrEqualTo(root.get("inserted_datetime"),date1 );
//		predicates[1] = cb.greaterThanOrEqualTo(root.get("inserted_datetime"), dtime);
//		predicates[2] = cb.equal(root.get("spacetype"),"Dining Area");
//		query.multiselect((cb.avg(root.get("peoplecount")))).where(predicates);
		
		javax.persistence.criteria.CriteriaQuery<Double> query = cb.createQuery(Double.class);
		Root<Cafeteria> root = query.from(Cafeteria.class);
		Predicate[] predicates = new Predicate[3];
		predicates[0] = cb.lessThanOrEqualTo(root.get("inserted_datetime"),dt );
		predicates[1] = cb.greaterThanOrEqualTo(root.get("inserted_datetime"), dtime);
		predicates[2] = cb.equal(root.get("spacetype"),"Dining Area");
		query.multiselect((cb.avg(root.get("peoplecount")))).where(predicates);
		avg=session.createQuery(query).getSingleResult();
			
		//List<Cafeteria> results =  (List<Cafeteria>) session.createQuery("Select avg(peoplecount) from Cafeteria where ").list();
		//Query q = session.createQuery(query);
		//results=(List) q;
		//results=(Integer) q.uniqueResult();
		//results= (List<Cafeteria>) q;
		//results = q.getResultList();
		//avg = (Double) ((Criteria) results).list().get(0);
		
		//avg = q.getSingleResult();
		System.out.println(avg+"inn");
		//Integer k=avg.intValue();
		
		//System.out.println(k+"inn");
		
		}
//		for(Cafeteria peoplecount:results) {
//			a=peoplecount.getPeoplecount();
//			//System.out.println(results);
//			System.out.println(a.intValue());
//		}
//		//int avg;
////	
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		return avg;
		
	}
	
	
	
	public Double getFromBaseService() throws ParseException {
		Session session = sessionFactory.getCurrentSession();
		List<Cafeteria> results=null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Double avg=null;
		System.out.println("done");
		System.out.println("repo insert");
		Date dt = new Date();
//		String d= ("2020-12-01 12:05:00");  
//	    Date date1=dateFormat.parse(d);
		try {
			 Calendar c = Calendar.getInstance();
		     c.setTime(dt);
		     c.add(Calendar.MINUTE, -30);
		     Date dtime = c.getTime();
		     System.out.println(dt);
		     System.out.println(dtime);
		CriteriaBuilder cb = session.getCriteriaBuilder();
		javax.persistence.criteria.CriteriaQuery<Double> query = cb.createQuery(Double.class);
		Root<Cafeteria> root = query.from(Cafeteria.class);
		Predicate[] predicates = new Predicate[3];
		predicates[0] = cb.lessThanOrEqualTo(root.get("inserted_datetime"),dt );
		predicates[1] = cb.greaterThanOrEqualTo(root.get("inserted_datetime"), dtime);
		predicates[2] = cb.equal(root.get("spacetype"),"Service Area");
		query.multiselect((cb.avg(root.get("peoplecount")))).where(predicates);
		avg=session.createQuery(query).getSingleResult();
		System.out.println(avg+"inn");
		}

		catch(Exception e) {
			e.printStackTrace();
		}
		
		return avg;
		
	}
	
	
	
	
	
	
//	public List<Cafeteria> getDiffTimeCountByDiningArea(Date dt) throws ParseException {
//	/*List<Cafeteria> results = null;
//	try {
//		
//		//read current time and take five min difference from curren time 
//		
//		
//		
//	Session session = this.sessionFactory.getCurrentSession();
//	Criteria crit = session.createCriteria(Cafeteria.class);
//	crit.add(Restrictions.eq("spacetype",spacetype));
//	// add restriction datetime <=differencetime  and datetime >= current time 
//	
//	results = crit.list();
//	}catch (Exception e) {
//		e.printStackTrace();
//	}
//	return results;*/
//	Session session = this.sessionFactory.getCurrentSession();
//	
//	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//	List<Cafeteria> results=null;
//	try {
//                           
//	 Calendar c = Calendar.getInstance();
//     c.setTime(dt);
//     c.add(Calendar.MINUTE, -5);
//     Date dtime = c.getTime();
//    
//      String d= (dateFormat.format(dtime));
//      
//      Date date1=dateFormat.parse(d);
//      System.out.println("Updated Date " + d);
//     //System.out.println("Updated Date " + dateFormat.format(e);
//    CriteriaBuilder cb = session.getCriteriaBuilder();
//	javax.persistence.criteria.CriteriaQuery<Cafeteria> query = cb.createQuery(Cafeteria.class);
//	Root<Cafeteria> root = query.from(Cafeteria.class);
//		//query.select(root).where(cb.equal(root.get("datetime"),dtime,dt));
//	Predicate[] predicates = new Predicate[2];
//	predicates[0] = cb.lessThanOrEqualTo(root.get("datetime"),dt );
//	predicates[1] = cb.greaterThanOrEqualTo(root.get("datetime"), dtime);
//	query.select(root.get("diningArea")).where(predicates);
//	Query<Cafeteria> q = session.createQuery(query);
//	results = q.getResultList();
//	}
//	catch(Exception e){
//		e.printStackTrace();
//		
//	}
//     
//	return results;
//	
//}
	
	
	
	
	
//	/*public List<Cafeteria> getCount(String spacetype) {
//	    Session session = this.sessionFactory.getCurrentSession();
//	    String hql;
//	    if(spacetype.equals("service")) {
//	       
//	   
//	        hql = "SELECT peoplecount from Cafeteria  where spacetype='service'";
//	    }
//	    else
//	    {
//	         hql = "SELECT peoplecount from Cafeteria where spacetype='dining'";
//	    }
//	    Query query = session.createQuery(hql);
//	    List results = ((org.hibernate.query.Query<Cafeteria>) query).list();
//	   
//	    return results;
//	}*/
//	
//	@SuppressWarnings("unchecked")
//	public List<Cafeteria> getCountByServiceArea(Date dt) {
//	    Session session = this.sessionFactory.getCurrentSession();
//	   /* List<Cafeteria> results=session.createQuery("FROM Cafeteria")
//	    		.setParameter("currentDate", dt)
//	    		.list();*/
//	    /*Criteria crit = session.createCriteria(Cafeteria.class);
//		crit.add(Restrictions.eq("datetime",dt));*/
//		CriteriaBuilder cb = session.getCriteriaBuilder();
//		javax.persistence.criteria.CriteriaQuery<Cafeteria> query = cb.createQuery(Cafeteria.class);
//		Root<Cafeteria> root = query.from(Cafeteria.class);
//		//query.select(root.get("serviceArea")).where(cb.equal(root.get("datetime"),dt));
//		Predicate[] predicates = new Predicate[2];
//		predicates[0] = cb.equal(root.get("datetime"),dt );
//		predicates[1] = cb.equal(root.get("spacetype"), "service");
//		query.select(root.get("peoplecount")).where(predicates);
//		Query<Cafeteria> q = session.createQuery(query);
//		List<Cafeteria> results = q.getResultList();
//		return results;
//	}
//	
//	@SuppressWarnings("unchecked")
//	public JSONArray getCountByDiningArea(Date dt) {
//		 JSONArray responseArray = new JSONArray();
//		//JSONObject jsonObj = new JSONObject();
//	    Session session = this.sessionFactory.getCurrentSession();
//	    CriteriaBuilder cb = session.getCriteriaBuilder();
//		javax.persistence.criteria.CriteriaQuery<Cafeteria> query = cb.createQuery(Cafeteria.class);
//		Root<Cafeteria> root = query.from(Cafeteria.class);
//		Predicate[] predicates = new Predicate[2];
//		predicates[0] = cb.equal(root.get("inserted_datetime"),dt );
//		predicates[1] = cb.equal(root.get("spacetype"), "Dining Area");
//		query.select(root.get("peoplecount")).where(predicates);
//		//query.select(root.get("spacetype")).where(cb.equal(root.get("datetime"),dt));
//		Query<Cafeteria> q = session.createQuery(query);
//		List<Cafeteria> results = q.getResultList();
//		for (int j = 0; j < results.size(); j++) {
//			System.out.println(results.get(j));
//			 JSONObject jsonObj = new JSONObject();
//			 
//			 jsonObj.put("Service Area", results.get(j));
//			 System.out.println(jsonObj);
//           responseArray.put(jsonObj);
//           System.out.println(responseArray);
//           return responseArray;
//           
//		}
//		 System.out.println("jjjjjj");
//		 System.out.println(responseArray);
//		return responseArray;
//	}

	
	
	@SuppressWarnings("unchecked")
	public List<Cafeteria> findPeopleCountForDateRange(Date startdate, Date enddate) {
		Session session = this.sessionFactory.getCurrentSession();
		List<Cafeteria> results=session.createQuery("SELECT peoplecount FROM Cafeteria AS c WHERE c.datetime BETWEEN :startdate AND :enddate ")
		.setParameter("startdate", startdate)
		.setParameter("enddate", enddate)
		.list();
		return results;
		
	}



	/*public List<Cafeteria> getTimeForDate(Date datetime) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria crit = session.createCriteria(Cafeteria.class);
		crit.add(Restrictions.eq("datetime",datetime));
		List<Cafeteria> results = crit.list();
		return results;
	}*/
	

	


}
