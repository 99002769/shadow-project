package com.grokonez.datetimerestapi.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "datetimemodel")
public class DateTimeModel {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
    /*@Column	
    @Temporal(TemporalType.DATE)
    @JsonFormat(pattern="yyyy-MM-dd")
    private Date date;*/
    
    @Column
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date datetime;
    
    /*@Column
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="Europe/Paris")
    private Date datetimewithzone;
    
    @Column
    @Temporal(TemporalType.TIMESTAMP)
    private Date defaultformatdatetime;*/
    
    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public DateTimeModel() {}
    
    public DateTimeModel(long id, Date datetime) {
		super();
		this.id = id;
		this.datetime = datetime;
	}

	@Override
	public String toString() {
		return "DateTimeModel [id=" + id + ", datetime=" + datetime + "]";
	}

	

	
    
   
}