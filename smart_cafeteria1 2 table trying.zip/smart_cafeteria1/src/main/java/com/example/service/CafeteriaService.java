package com.example.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.CafeteriaRepository;
import com.example.model.CafeOccupancyIntermediate;
import com.example.model.Cafeteria;
import com.example.utils.RandomUtil;
import com.example.utils.RandomUtilIntermediate;

@Service
public class CafeteriaService {

	
		
	@Autowired
	CafeteriaRepository cafeteriaRepository;
	
	
	public void setUserReposatory(CafeteriaRepository cafeteriaRepository) {
		this.cafeteriaRepository = cafeteriaRepository;
	}

	public Cafeteria save(Cafeteria cafeteria){
		 return cafeteriaRepository.save(cafeteria);
	}
	
	public List<Cafeteria> getAllUsers() {
		return cafeteriaRepository.getAllUsers();
	}
	
	public Cafeteria getDetails(long id) {
		return cafeteriaRepository.getDetails(id);
	}
	
	
	public void saveOccupancyBase() {
		
			
		Cafeteria c = randomcall1();
		Cafeteria d = randomcall2();
		cafeteriaRepository.saveOccupancyBase(c);
		cafeteriaRepository.saveOccupancyBase(d);
		//System.out.println("in service post");
		//System.out.println(c+"in service post");
		
	}

	private Cafeteria randomcall1() {
		Cafeteria cafe=new Cafeteria();
		cafe.setSpacetype(RandomUtil.RandomDining());
		cafe.setPeoplecount(RandomUtil.RandomInt(1,150));
		cafe.setInserted_datetime(RandomUtil.NewDate());
		cafe.setCreated_date(RandomUtil.NewDate());
		cafe.setCreated_by(RandomUtil.admin());
		cafe.setModified_date(RandomUtil.NewDate());
		cafe.setModified_by(RandomUtil.admin());
		//System.out.println(cafe);
		return cafe;
		
	}
	
	private Cafeteria randomcall2() {
		Cafeteria cafe1 = new Cafeteria();
		cafe1.setSpacetype(RandomUtil.RandomService());
		cafe1.setPeoplecount(RandomUtil.RandomInt(1,50));
		cafe1.setInserted_datetime(RandomUtil.NewDate());
		cafe1.setCreated_date(RandomUtil.NewDate());
		cafe1.setCreated_by(RandomUtil.admin());
		cafe1.setModified_date(RandomUtil.NewDate());
		cafe1.setModified_by(RandomUtil.admin());
		//System.out.println(cafe1);
		return cafe1;
		
	}
	
	public void saveOccupancyIntermediate() {
		CafeOccupancyIntermediate ci = random1();
		CafeOccupancyIntermediate cd = random2();
		cafeteriaRepository.saveOccupancyIntermediate(ci);
		cafeteriaRepository.saveOccupancyIntermediate(cd);
		System.out.println("service inter");
	}

	public CafeOccupancyIntermediate random1(){
		
		CafeOccupancyIntermediate cafeInter = new CafeOccupancyIntermediate();
		cafeInter.setID(RandomUtilIntermediate.Id());
		cafeInter.setSpacetype(RandomUtil.RandomDining());
		System.out.println("service inter1");
		//cafeInter.setPeoplecount(RandomUtil.RandomInt(1, 50));
		cafeInter.setPeoplecount(cafeteriaRepository.getFromBase());
		cafeInter.setTimeslot(RandomUtilIntermediate.timeslot());
		cafeInter.setInserted_date(RandomUtilIntermediate.NewDate());
		cafeInter.setCreated_date(RandomUtil.NewDate());
		cafeInter.setCreated_by(RandomUtil.admin());
		cafeInter.setModified_date(RandomUtil.NewDate());
		cafeInter.setModified_by(RandomUtil.admin());
		return cafeInter;
	}
	
public CafeOccupancyIntermediate random2(){
		
		CafeOccupancyIntermediate cafeInter = new CafeOccupancyIntermediate();
		cafeInter.setID(RandomUtilIntermediate.Id());
		cafeInter.setSpacetype(RandomUtil.RandomService());
		System.out.println("service inter2");
		//cafeInter.setPeoplecount(RandomUtil.RandomInt(1, 50));
		cafeInter.setPeoplecount(cafeteriaRepository.getFromBase());
		cafeInter.setTimeslot(RandomUtilIntermediate.timeslot());
		cafeInter.setInserted_date(RandomUtilIntermediate.NewDate());
		cafeInter.setCreated_date(RandomUtil.NewDate());
		cafeInter.setCreated_by(RandomUtil.admin());
		cafeInter.setModified_date(RandomUtil.NewDate());
		cafeInter.setModified_by(RandomUtil.admin());
		return cafeInter;
	}
	
	/*public List<Cafeteria> getBySpaceType(String spacetype) {
		return cafeteriaRepository.getBySpaceType(spacetype);
	}*/
	
/*	public List<Cafeteria> getCount(String spacetype){
		return cafeteriaRepository.getCount(spacetype);
	}*/
	

	/*public List<Cafeteria> getTimeForDate(Date datetime) {
		
		return cafeteriaRepository.getTimeForDate(datetime);
	}*/

}
