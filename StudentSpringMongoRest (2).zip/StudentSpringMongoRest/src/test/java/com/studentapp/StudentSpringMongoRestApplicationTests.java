package com.studentapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentSpringMongoRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
