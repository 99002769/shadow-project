package com.example.service;


import java.util.Date;
import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class RandomUtil {
	
	
	
	public static  String RandomStringFromArray()
	{    
		String[] arr={"dining","service"};
	    Random r=new Random();        
	    int randomNumber=r.nextInt(arr.length);
	    return arr[randomNumber];   
	}
	
	public static  Integer RandomInt(int min, int max)
	{
		    return (int) ((Math.random() * (max - min)) + min);
			
	}
	
	public static Date NewDate() 
	{
		 Date date = new Date();
		 return date;
	      
	}
	public static String admin()
	{
		return "admin";
	}

}
