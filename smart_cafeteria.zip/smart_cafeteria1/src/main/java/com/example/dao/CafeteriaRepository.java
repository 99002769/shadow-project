package com.example.dao;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.model.Cafeteria;

@Repository
@Transactional
public class CafeteriaRepository {
	
	@Autowired
	private SessionFactory sessionFactory;
 
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	@Transactional
	public Cafeteria save(Cafeteria cafeteria){
		 Session session = this.sessionFactory.getCurrentSession();
		 session.save(cafeteria);
		 return cafeteria;
	}
	
	
	public List<Cafeteria> getAllUsers() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Cafeteria>  cafeteriaList = session.createQuery("from cafe",Cafeteria.class).getResultList();
		return cafeteriaList;
	}
	
	public Cafeteria getDetails(long id) {
		Session session = this.sessionFactory.getCurrentSession();
		Cafeteria cafeteria = (Cafeteria) session.get(Cafeteria.class, id);
		return cafeteria;
	}
	
	@SuppressWarnings("unchecked")
	public List<Cafeteria> getAllUsersByCriteria() {
		Session session = this.sessionFactory.getCurrentSession();
		@SuppressWarnings("deprecation")
		Criteria crit = session.createCriteria(Cafeteria.class);
		return crit.list();
	}
	
	public List<Cafeteria> getBySpaceType(String spacetype) {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria crit = session.createCriteria(Cafeteria.class);
		crit.add(Restrictions.eq("spacetype",spacetype));
		List<Cafeteria> results = crit.list();
		return results;
	}
	

	


}
