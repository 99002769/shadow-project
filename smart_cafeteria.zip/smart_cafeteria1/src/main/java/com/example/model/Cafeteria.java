package com.example.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "cafe")
public class Cafeteria implements Serializable{
	
	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue( strategy= GenerationType.AUTO,generator="native")
	private long id;
	
	@Column(name = "spacetype")
	private String spacetype;
	
	@Column(name = "peoplecount")
	private Integer peoplecount;
	
	@Column(name = "createdby")
	private String createdby;
	
	@Column
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date datetime;
	
	public long getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSpacetype() {
		return spacetype;
	}

	public void setSpacetype(String spacetype) {
		this.spacetype = spacetype;
	}

	public Integer getPeoplecount() {
		return peoplecount;
	}

	public void setPeoplecount(Integer peoplecount) {
		this.peoplecount = peoplecount;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	
	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}

	
	public Cafeteria(String spacetype, Integer peoplecount, String createdby, Date datetime) {
		super();
		
		this.spacetype = spacetype;
		this.peoplecount = peoplecount;
		this.createdby = createdby;
		this.datetime = datetime;
	}

	

	public Cafeteria() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Cafeteria [id=" + id + ", spacetype=" + spacetype + ", peoplecount=" + peoplecount + ", createdby="
				+ createdby + ", datetime=" + datetime + "]";
	}

	
	
	

}
