package com.example.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name = "cafes")
public class Cafeteria {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "spacetype")
	private String spacetype;
	
	@Column(name = "peoplecount")
	private Integer peoplecount;
	
	@Column(name = "createdby")
	private String createdby;
	
	@Column
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date datetime;
	
	
	public Cafeteria(Integer id, String spacetype, Integer peoplecount, String createdby, Date createdDateTime) {
		super();
		this.id = id;
		this.spacetype = spacetype;
		this.peoplecount = peoplecount;
		this.createdby = createdby;
		this.datetime = createdDateTime;
	}
	public Date getdatetime() {
		return datetime;
	}
	public void setdatetime(Date createdDateTime) {
		this.datetime = createdDateTime;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSpacetype() {
		return spacetype;
	}
	public void setSpacetype(String spacetype) {
		this.spacetype = spacetype;
	}
	public Integer getPeoplecount() {
		return peoplecount;
	}
	public void setPeoplecount(Integer peoplecount) {
		this.peoplecount = peoplecount;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	@Override
	public String toString() {
		return "Cafeteria [id=" + id + ", spacetype=" + spacetype + ", peoplecount=" + peoplecount + ", createdby="
				+ createdby + ", createdDateTime=" + datetime + "]";
	}
	
	public Cafeteria() {
		
	}
	

}
