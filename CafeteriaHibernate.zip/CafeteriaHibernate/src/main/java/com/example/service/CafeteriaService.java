package com.example.service;

import java.util.List;

import com.example.model.Cafeteria;

public interface CafeteriaService {

	 Cafeteria save(Cafeteria product);
	 List<Cafeteria> saveall(List<Cafeteria> products);
	 List<Cafeteria> get();
	 Cafeteria getProductById(int id);
	 List<Cafeteria> getBySpacetype(String spacetype);
}
