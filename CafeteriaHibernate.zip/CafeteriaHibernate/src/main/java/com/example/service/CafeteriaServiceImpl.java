package com.example.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.CafeteriaRepository;
import com.example.model.Cafeteria;
@Service
@Transactional
public class CafeteriaServiceImpl implements CafeteriaService {

	
	CafeteriaRepository cafeteriaRepository;
	
	@Autowired
	public void setCafeteriaRepository(CafeteriaRepository cafeteriaRepository) {
		this.cafeteriaRepository=cafeteriaRepository;
	}
	
	
	
	public List<Cafeteria> getBySpacetype(String spacetype) {
		
		return cafeteriaRepository.getBySpacetype(spacetype);
	}



	public Cafeteria save(Cafeteria product) {
		return cafeteriaRepository.save(product);
		
		
	}



	public List<Cafeteria> saveall(List<Cafeteria> products) {
		
		return cafeteriaRepository.saveall(products);
	}



	public List<Cafeteria> get() {
		
		return cafeteriaRepository.get();
	}



	public Cafeteria getProductById(int id) {
		return cafeteriaRepository.getProductById(id);
		
		
	}

}
