package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Cafeteria;
import com.example.service.CafeteriaService;

@RestController
public class CafeteriaController {
	 @Autowired
	 CafeteriaService cafeteriaService;
	 
	 
	 	@PostMapping("/add")
	    public Cafeteria add(@RequestBody Cafeteria cafeteria) {
	        return cafeteriaService.save(cafeteria);
	    }

	    @PostMapping("/adds")
	    public List<Cafeteria> adds(@RequestBody List<Cafeteria> cafeteria) {
	        return cafeteriaService.saveall(cafeteria);
	    }

	    @GetMapping("/details")
	    public List<Cafeteria> findAll() {
	        return cafeteriaService.get();
	    }

	    @GetMapping("/productById/{id}")
	    public Cafeteria findProductById(@PathVariable int id) {
	        return cafeteriaService.getProductById(id);
	    }
	   
	    @GetMapping("/cafeteria/spacetype/{spacetype}")
	    public List<Cafeteria> getSpacetype(@PathVariable("spacetype") String spacetype) {
			return cafeteriaService.getBySpacetype(spacetype);	
	    }
	    
}
