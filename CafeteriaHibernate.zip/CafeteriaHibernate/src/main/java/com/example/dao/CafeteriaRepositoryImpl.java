package com.example.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.model.Cafeteria;


@Repository
public class CafeteriaRepositoryImpl implements CafeteriaRepository {

	@Autowired
	private SessionFactory sessionFactory;
	
	
	protected Session getSession(){
		  return sessionFactory.getCurrentSession();
		 }
	
	 @SuppressWarnings("unchecked")
	public List<Cafeteria> getBySpacetype(String spacetype) {
		
		return (List<Cafeteria>) getSession().get(Cafeteria.class, spacetype);
	}

	public Cafeteria save(Cafeteria product) {
		
		return (Cafeteria) getSession().save(product);
		
	}
	 @SuppressWarnings("unchecked")
	public List<Cafeteria> saveall(List<Cafeteria> products) {
		
		return (List<Cafeteria>) getSession().save(products);
	}

	@SuppressWarnings("unchecked")
	public List<Cafeteria> get() {
		// TODO Auto-generated method stub
		return (List<Cafeteria>) getSession().createCriteria(Cafeteria.class).list();
	}

	public Cafeteria getProductById(int id) {
		
		return (Cafeteria) getSession().get(Cafeteria.class, id);
		
	}

	

	/*public List<Cafeteria> findAllByDatetimeBetween(Date dateTimeStart, Date dateTimeEnd) {
		
		return getSession()
	}*/

}
