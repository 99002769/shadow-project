package com.example.demo.service;


import java.util.Date;
import java.util.List;



import com.example.demo.model.Cafeteria;

public interface CafeteriaService {
	
	

	List<Cafeteria> getBySpacetype(String spacetype);
	
	//List<Cafeteria> getByDate(Date datetime);
	

}
