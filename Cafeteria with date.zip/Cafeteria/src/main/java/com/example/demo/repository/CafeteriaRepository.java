package com.example.demo.repository;



import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;



import com.example.demo.model.Cafeteria;




public interface CafeteriaRepository extends JpaRepository<Cafeteria,Integer> {
	
	

	List<Cafeteria> getBySpacetype(String spacetype);
	
	

	
	/*
	@Query("select DATE(datetime) from cafes");
	List<Cafeteria> getByDate(Date datetime);
	*/
	
	List<Cafeteria> findAllByDatetimeBetween(
			Date dateTimeStart,
			Date dateTimeEnd);

	/*@Query("select d from cafes d where d.datetime <= :datetime")
	List<Cafeteria> findAllWithDatetimeBefore(
	@Param("datetime") Date datetime);*/
	        
	
	}
