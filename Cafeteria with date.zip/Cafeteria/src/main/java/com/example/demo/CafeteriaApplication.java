package com.example.demo;

import java.util.Calendar;
import java.util.TimeZone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafeteriaApplication {

	public static void main(String[] args) {
		
		
		TimeZone tz = Calendar.getInstance().getTimeZone();
		System.out.println(tz.getID());
		SpringApplication.run(CafeteriaApplication.class, args);
	}

}
