package com.example.demo.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Cafeteria;
import com.example.demo.repository.CafeteriaRepository;
import com.example.demo.service.CafeteriaServiceImpl;

@RestController
public class CafeteriaController {
	
	
	@Autowired
	private CafeteriaServiceImpl service;
	
	@Autowired
	private CafeteriaRepository repos;
	
	 @PostMapping("/add")
	    public Cafeteria add(@RequestBody Cafeteria cafeteria) {
	        return service.save(cafeteria);
	    }

	    @PostMapping("/adds")
	    public List<Cafeteria> adds(@RequestBody List<Cafeteria> cafeteria) {
	        return service.saveall(cafeteria);
	    }

	    @GetMapping("/details")
	    public List<Cafeteria> findAll() {
	        return service.get();
	    }

	    @GetMapping("/productById/{id}")
	    public Cafeteria findProductById(@PathVariable int id) {
	        return service.getProductById(id);
	    }
	   
	    @GetMapping("/cafeteria/spacetype/{spacetype}")
	    public List<Cafeteria> getSpacetype(@PathVariable("spacetype") String spacetype) {
			return service.getBySpacetype(spacetype);	
	    }
	    
	   /* 
	    @GetMapping("/cafeteria/date/{date}")
	    public List<Cafeteria> getByDate(@PathVariable("date") Date datetime) {
			return service.getByDate(datetime);	
	    }
	    */
	    
//	    List<DateTimeModel> findAllByDatetimeBetween(Date dateTimeStart,Date dateTimeEnd);
//  
//	    @Query("select d from DateTimeModel d where d.datetime <= :datetime")
//	    List<DateTimeModel>findAllWithDatetimeBefore(@Param("datetime") Date datetime);
	    
	    
	    @GetMapping("/getdatetime")
	    public Iterable<Cafeteria> getDateTimeModel() {
	      return repos.findAll();
	    }
	    
	    @PostMapping("/postdatetime")
	    public String postDateTimeModel(@RequestBody Cafeteria datetime) {
	    	repos.save(datetime);
	      return "Done!";
	    }
	    
	   @GetMapping("/getallbydatetimebetween")
	    public List<Cafeteria> getAllByDatetimeBetween(
	        @RequestParam("startdate") @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss") Date startdate,
	        @RequestParam("enddate") @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss") Date enddate) {
	      return repos.findAllByDatetimeBetween(startdate, enddate);
	    }
	    
	   /* @GetMapping("/getallwithdatetimebefore")
	    public List<Cafeteria> getAllWithDatetimeBefore(
	        @RequestParam("datetime") @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss") Date createdDateTime){
	   
	      return repos.findAllWithDatetimeBefore(createdDateTime);
	    }*/
    
   
	 
	}

	    
	

